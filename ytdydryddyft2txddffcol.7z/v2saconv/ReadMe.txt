ytd/ydr/ydd/yft > txd/dff/col (tool) by DK22Pac
06/01/2016
Thanks to: All guys who researched RAGE formats, listener, OpenIV team, Dageron, aru, tgascoigne and others.
Thanks to M4K3, ThirteenAG, Automan.